package com.som.services;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SP_a {

	public String getServerTime(){
		Date dNow = new Date( );
	    SimpleDateFormat ft = new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

		return "Service Provider SP_a's Current Date and time: " + ft.format(dNow);
	}

	public String greeting(String guest){
		return "Welcome to SP_a "+guest;
	}
}
