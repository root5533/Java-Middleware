
Instructions to run the program.
================================
# You have to have the JRE installed and setup the path variable in your system.
# There are two .jar files in the "dist" folder named server.jar and client.jar.
# !Important, you have to run the server.jar(server program) first. For that open the terminal in the "dist" directory and enter the command below.

            java -jar server.jar

# Then run the client.jar(consumer program). For that open another terminal window and run the below command.    

            java -jar client.jar

# The service lookup with necessary instructions will be shown up.
# You can enter commands according to the service lookup like in a linux terminal.


Technical Details.
==================
# The server will start at port 5555.
# The server can handle concurrent consumer programs(clients requests) upto 50(can be increased in the source code).
# There will be all the source files in the src folder with 3 packages(com.som.client, com.som.server, com.som.services).
# Client program resides in com.som.client and server program resides in com.som.server.
# com.som.services has all the service providers. Currently there are 3 service providers SP_a,SP_b and SP_c.
# SP_a and SP_b have services added and SP_c is empty.
# Service provider "C" can add their services to that SP_c class and register them in the middleware by adding method names to the hashmap called "registry" in the source Handler.java in com.som.server package. (line 38 in the source code)

            //Register Services
		registry.put("a1", "getServerTime");
		registry.put("a2", "greeting");
		registry.put("b1", "getGender");
		registry.put("b2", "getYear");
		registry.put("b3", "getMonth");

# This registry will send to every consumer program which connect to the server. So that consumer program can get the services via this middleware.

